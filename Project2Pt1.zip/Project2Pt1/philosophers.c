/* 
Author:  Josiah Findley and Joshua Nichols
Course:  COMP 325, Computer Architecture
Date:    05 November 2021
Description:   This file implements the philosopher.c 
portion of the dp program Pt 1 using semaphors and mutex locks 
Compile and run with:  make all
*/

#include <pthread.h>
#include <stdio.h>
#include <time.h>
#include <errno.h>
#include <string.h>
#include "dp.h"

/**************Philosopher Functions****************/

//function for getting a random number from the list
int get_next_number(){
    //return next random number
    int retVal = rand_numbers[rand_position];
    rand_position++; //inc position
    return retVal;//return
}

//function that simulates the philosopher operation
void *philosopher(void *param){

  //Variable Dicationary
  int think_time;
  int eat_time;
  int *lnumber = (int *)param;
  int number = *lnumber;
  int numLoop = 5; 


  while (numLoop > 0) {//run 5 times
    //Think
    pthread_mutex_lock(&mutex_rand); //lock rand
    think_time = get_next_number();//Generate think time
    pthread_mutex_unlock(&mutex_rand); //unlock rand
    sleep(think_time);   
    //Try to PickUp
		pickup_chopsticks(number);
    //Eat
    pthread_mutex_lock(&mutex_rand); //lock rand
    eat_time = get_next_number();//Generate eat time
    pthread_mutex_unlock(&mutex_rand); //unlock rand
    sleep(eat_time);
    //Put Down
    return_chopsticks(number);	
    
    //Decrement times through loop
    numLoop--;
	}
 //thread exits
	pthread_exit(0);
}

//function for the philosopher to pickup the chopsticks
void pickup_chopsticks(int number){
  pthread_mutex_lock(&mutex_lock); //lock 
  state[number] = HUNGRY; //set state to hungry
  test(number); //test if can pickup
  pthread_mutex_unlock(&mutex_lock); //unlock lock 
  sem_wait(&sem_vars[number]); //waits till it is able to pick up chopsticks
}

//function for the philosopher to return the chopsticks
void return_chopsticks(int number){
  pthread_mutex_lock(&mutex_lock); //lock 
  state[number] = THINKING; //return to thinking
  test((number + NUMBER-1) % NUMBER);//test left
  test((number + 1) % NUMBER);//test right
  pthread_mutex_unlock(&mutex_lock); //unlock lock 
}

//Test philosophers on either side
void test(int number) {
  if ((state[(number + NUMBER-1) % NUMBER] != EATING) && //Check Left
    (state[number] == HUNGRY) && //want to compete
    (state[(number + 1) % NUMBER] != EATING)) { //Check Right
    state[number] = EATING; //phi[i] can eat
    sem_post(&sem_vars[number]); //wake up phi[i] if blocked
  }
}


