/*
Author:  Josiah Findley and Joshua Nichols
Course:  COMP 325, Computer Architecture
Date:    05 November 2021
Description:   This file implements the main.c 
portion of the dp program
Compile and run with:  make all
*/

#include "dp.h"
#include <pthread.h>
#include <stdio.h>
#include <semaphore.h>
#include <string.h>
#include <errno.h>

//Variable Dictionary
pthread_t philosophers[NUMBER];
rand_position = 0;

//Main Method
int main(int argc, char **argv)
{

  //read file
  if (parse_file(argc, argv[1])==-1){
    return -1; //failed to parse file
  }

  //initialize
  int i;
	init();
	create_philosophers();
  //Join Threads back together
	for (i = 0; i < NUMBER; i++)
		pthread_join(philosophers[i], NULL);
  
  //return
	return 0;
}

//Initialize
void init()
{
  //loop var
  int i;
  //init mutex locks
	if ( pthread_mutex_init(&mutex_rand, NULL) != 0)
		printf("%s\n",strerror(errno));
   if ( pthread_mutex_init(&mutex_lock, NULL) != 0)
		printf("%s\n",strerror(errno));

  //init semaphores, id, and state for each thread
  for(i = 0; i < NUMBER; i++){
      if(sem_init(&sem_vars[i], 0, 0) == -1)//set semaphores to 0
		      printf("error init sem_vars\n");
      thread_id[i] = i;//set id
      state[i] = THINKING;//set state
  }
}

//Create Philosophers
void create_philosophers()
{
  int i; //loop var
	for (i = 0; i < NUMBER; i++) { //Create threads
		pthread_create(&philosophers[i], 0, philosopher, (void *)&thread_id[i]);
	}
}

//parse file for random numbers
int parse_file(int argc, char *fp)
{
 // loop var
 int i = 0;
 //error checking
 if(argc !=2) {
     printf("wrong number of args!\n");
     return -1; //return failure
   }
 FILE * file = fopen(fp, "r"); //open file in read
 if(file == NULL) {
    printf("file not found!\n");
    return -1; //return failure
 }
 //temp storage
 char int_arr[MAX_LENGTH];
 //
 if(fgets(int_arr, MAX_LENGTH, file)) { //read from file
    char * val = strtok(int_arr, " "); //point to initial val
    while(val){//while vals
       rand_numbers[i++] = atoi(val);//add to rand_numbers array as ints
       val = strtok(NULL, " "); //point to next val
    }
  }
  else{
    printf("failed to read from file!\n");
    return -1; //return failure
  }
  
  //clean up
  fclose(file);
  return 0; //return success
}
