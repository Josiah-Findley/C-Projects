/* 
Author:  Josiah Findley and Joshua Nichols
Course:  COMP 325, Computer Architecture
Date:    01 December 2021
Description:   This file implements the monitoring of allocated memory
Messages the console when PERCENT_BARRIER is crossed
Compile and run with:  gcc -o task3 task3.c, ./task3&
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX_SIZE 50 //Max array length
#define PERCENT_BARRIER 0.85 //Max percent for memory allocation

int main()
{
    //Var Dictionary
    FILE *p; //pipe to grab necessary info
    //Ints for memory amount
    int availableMem;
    int totalMem;
    //floats for old and new percentages
    float percentAllocated;
    float percentAllocated2 = 0;
    //Buffers for the memory amount
    char availableMemChar[MAX_SIZE];
    char totalMemChar[MAX_SIZE];
    
    //Var holders
    int n = 0; //var counter
    char c;

    //Get total memory
    p = popen("free| awk '/Mem: /{print $2}'","r");//Grab from pipe
    if( p == NULL)//failure
    {
        puts("Unable to open process");
        return(1);
    }
    while( (c=fgetc(p)) != EOF)
        totalMemChar[n++] = (char) c;//Add to string
    totalMem = atoi(totalMemChar);//convert to int
    pclose(p);
    
    while(1){
      sleep(1); //Check every 1 second
      
      //Get available memory
      n=0;
      p = popen("free| awk '/Mem: /{print $7}'","r");//Grab from pipe
      if( p == NULL)//failure
      {
          puts("Unable to open process");
          return(1);
      }
      while( (c=fgetc(p)) != EOF)
          availableMemChar[n++] = (char) c; //Add to string
      availableMem = atoi(availableMemChar);//convert to int
      pclose(p);

      //percent allocated
      percentAllocated = (totalMem-availableMem)/(float)totalMem;
      //Check the barriers
      if(percentAllocated>PERCENT_BARRIER&&percentAllocated2<PERCENT_BARRIER)//Crossing above the barrier
        printf("\nMore than %f%% is now being allocated!!!", PERCENT_BARRIER*100);
      else if(percentAllocated<PERCENT_BARRIER&&percentAllocated2>PERCENT_BARRIER)//Crossing below the barrier
        printf("\nLess than %f%% is now being allocated!!!", PERCENT_BARRIER*100);
      
      percentAllocated2 = percentAllocated; //set old number of percentAllocated to new one
      fflush(stdout);//flush
    }
    return(0);
}