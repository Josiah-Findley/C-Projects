/* 
Author:  Josiah Findley and Joshua Nichols
Course:  COMP 325, Computer Architecture
Date:    01 December 2021
Description:   This file implements the monitoring of allocated memory.
Kills user process when memory allocation goes above PERCENT_BARRIER
Compile and run with:  gcc -o task4 task4.c, ./task4&
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>

#define MAX_SIZE 50 //Max array length
#define PERCENT_BARRIER 0.85 //Max percent for memory allocation

int main()
{
    //Var Dictionary
    FILE *p; //pipe to grab necessary info
    //Ints for memory amount
    int availableMem;
    int totalMem;
    //floats for old and new percentages
    float percentAllocated;
    //Buffers for the memory amount
    char availableMemChar[MAX_SIZE];
    char totalMemChar[MAX_SIZE];
    char userProcessChar[MAX_SIZE];
    char killCommand[MAX_SIZE];
    
    //Var holders
    int n = 0; //var counter
    char c;

    //Get total memory
    p = popen("free| awk '/Mem: /{print $2}'","r");//Grab from pipe
    if( p == NULL)//failure
    {
        puts("Unable to open process");
        return(1);
    }
    while( (c=fgetc(p)) != EOF)
        totalMemChar[n++] = (char) c;//Add to string
    totalMem = atoi(totalMemChar);//convert to int
    pclose(p);
    
    while(1){
      sleep(1); //Check every 1 second
      
      //Get available memory
      n=0;
      p = popen("free| awk '/Mem: /{print $7}'","r");//Grab from pipe
      if( p == NULL)//failure
      {
          printf("Unable to open process");
          return(1);
      }
      while( (c=fgetc(p)) != EOF)
          availableMemChar[n++] = (char) c; //Add to string
      availableMem = atoi(availableMemChar);//convert to int
      pclose(p);

      //percent allocated
      percentAllocated = (totalMem-availableMem)/(float)totalMem;
      //Check the barriers
      if(percentAllocated>PERCENT_BARRIER){//Crossing above the barrier
            //Get number of first user process to kill
            n=0;
            p = popen("ps | awk 'NR==4 {print $1}'","r");//Grab from pipe
            if( p == NULL)//failure
            {
                printf("Unable to open process");
                return(1);
            }
            while( (c=fgetc(p)) != EOF){
                userProcessChar[n++] = (char) c;//Add to string
                }
            pclose(p);
            
            //Generate kill command
            strcpy(killCommand, "kill -9 ");
            strcat(killCommand, userProcessChar);
            //Run kill command
            p = popen(killCommand, "r");
            pclose(p);
            
      }
    }
    return(0);
}