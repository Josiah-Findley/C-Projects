/* 
Author:  Josiah Findley and Joshua Nichols
Course:  COMP 325, Computer Architecture
Date:    01 December 2021
Description:   This file implements one thread sleeping used with task2p2
Compile and run with:  gcc -o task2OnlyOneThread task2OnlyOneThread.c, ./task2OnlyOneThread
*/

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <time.h>


int main()
{
    
    char* foo = (char*)malloc(3322337203);

    for (long long i=0; i<3322337203; i++)
    {
        foo[i] = (char)i;
    }
    
    //have the process sleep
    sleep(100);
    printf("sleeping process");
           
    //return
    return 0;
}