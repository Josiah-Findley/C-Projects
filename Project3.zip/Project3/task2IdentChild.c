/* 
Author:  Josiah Findley and Joshua Nichols
Course:  COMP 325, Computer Architecture
Date:    01 December 2021
Description:   This file implements the forking of an identical child children 
Compile and run with:  gcc -o task2IdentChild task2IdentChild.c, ./task2IdentChild
*/

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <time.h>


int main()
{
    //Declare identifiers of children
    int pid;
    
	  pid = fork(); //fork first child

  	if(pid < 0){//failure
		  printf("fork failed\n"); 
	  	exit(-1); 
  	}
  
    //if child sleep 
    else if (pid == 0) {
        sleep(7);
        printf("child pid is %d my parent pid is %d\n", getpid(), getppid()); 
    }
  
    //if not
    else {//Parent process
        sleep(7); //sleep
        printf("parent process: my pid is %d\n", getpid());
      	wait(NULL); 
        printf("child is done! I can exit\n");                

    }
    //return
    return 0;
}