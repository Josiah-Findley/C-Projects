/* 
Author:  Josiah Findley and Joshua Nichols
Course:  COMP 325, Computer Architecture
Date:    01 December 2021
Description:   This file implements the forking of a child that then runs a prog that it is passed
Compile and run with:  gcc -o task2p2 task2p2.c, ./task2p2 task2OnlyOneThread
*/
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>


int main(int argc, char* argv[])
{
 // execute the file with the command line arguments      
  pid_t process;
  
  //fork
  process = fork();
  
  if (process < 0)
  {
      // fork() failed.
      exit(-1);
      return -1;
  }
  
  //Child
  if (process == 0)
  {      
  printf("child process!\n"); 
    if(argc<2){
      printf("add a file to run\n");
    }    
    else if(execv(argv[1], argv)==-1){
      return -1;//failure
    }
  }
  
  //Parent
  if (process > 0)
  {
      wait(NULL);
      printf("parent process: pid of my child is %d, my pid is %d\n", process, getpid());
  }
  return 0;
}