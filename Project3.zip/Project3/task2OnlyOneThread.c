/* 
Author:  Josiah Findley and Joshua Nichols
Course:  COMP 325, Computer Architecture
Date:    01 December 2021
Description:   This file implements one thread sleeping used with task2p2
Compile and run with:  gcc -o task2OnlyOneThread task2OnlyOneThread.c, ./task2OnlyOneThread
*/

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <time.h>


int main()
{
    //have the process sleep
    sleep(7);
    printf("sleeping process");
           
    //return
    return 0;
}