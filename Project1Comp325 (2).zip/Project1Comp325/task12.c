/*
Author:  Josiah Findley and Joshua Nichols
Course:  COMP 325, Computer Architecture
Date:    22 October 2021
Description:   This file implements the
Task12 program
Compile with:  gcc -o task12 task12.c
Run with:      ./task12
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>  
#include <sys/time.h> 
#include <limits.h>


//Global Vars
//use SHRT_MAX, INT_MAX, LONG_MAX to specify the large number. 
int divVal = INT_MAX;//short, int, or long for val 
int modVal = INT_MAX;//short, int, or long for val 
int numRuns = 5;

//for loop that divides a large number by 2k 10 million times (bitwise)
void runDivision(int k){//short, int, or long for k
  for(int i = 0; i<10000000; i++)
    divVal = divVal/(2*k);

}

//for loop that calculate the remainder of the division of a large number by divisor 10 million times (bitwise)
void runModulo(int divisor){//short, int, or long for divisor
  for(int i = 0; i<10000000; i++)
    modVal = modVal%divisor;
}

int main (int argc, char *argv[]) {
  //Timer Variables
  struct timeval  before, after;
  double waitTime;
  int k = 4;//short, int, or long
  
  //Division
  //Run 5 times and get avg
  for(int i = 0; i<numRuns; i++){
    gettimeofday(&before, NULL);//init time
    runDivision(k); // runModulo or runDivision
    gettimeofday(&after, NULL);//final time
    printf("Div time run %d is: %f\n",i,(double)(after.tv_usec-before.tv_usec)/1000 + (double)(after.tv_sec-before.tv_sec)*1000);
    waitTime += (double)(after.tv_usec-before.tv_usec)/1000 + (double)(after.tv_sec-before.tv_sec)*1000;
  }
  printf("Division Took Avg of %f msecs \n", waitTime/numRuns);
  
  //Modulo
  //Run 5 times and get avg
  waitTime=0; //reset wait time
  for(int i = 0; i<numRuns; i++){
    gettimeofday(&before, NULL);//init time
    runModulo(k); // runModulo or runDivision
    gettimeofday(&after, NULL);//final time
    printf("Mod time run %d is: %f\n",i,(double)(after.tv_usec-before.tv_usec)/1000 + (double)(after.tv_sec-before.tv_sec)*1000);
    waitTime += (double)(after.tv_usec-before.tv_usec)/1000 + (double)(after.tv_sec-before.tv_sec)*1000;
  }
  printf("Modulo Took Avg of %f msecs \n", waitTime/numRuns);

  }